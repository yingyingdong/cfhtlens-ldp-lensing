#icc mymath.c linklist.c e_profile_calibrationw2_lg.c -lm -I. -lfftw3 -openmp -o read -g
#export OMP_NUM_THREADS=32
date
./read
date


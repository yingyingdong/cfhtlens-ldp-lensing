//read_yang.c
int yang_cen(double (*pos)[3],int num,double xrange[2][2]);
int yang_group(double (*pos)[3],int num,double xrange[2][2]);

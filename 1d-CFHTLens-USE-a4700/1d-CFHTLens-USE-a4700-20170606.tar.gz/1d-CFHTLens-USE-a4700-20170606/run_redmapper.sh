mdir=/home/fydong/work/Romberg
#file=e_profile_calibrationw2_clusters_jzfield_ad_cra.c
#file=e_profile_calibrationw2_clusters_jzfield_ad_cra_zbin.c
#file=e_profile_calibrationw2_clusters_jzfield_ad_cra_zbin_onetime.c
#file=e_profile_calibrationw2_clusters_jzfield_adxy_cra_zbin_onetime.c
#file=e_profile_calibrationw2_clusters_jzfield_ad_cra_zbin_dsigma_onetime.c
#file=e_profile_calibrationw2_clusters_jzfield_ad_cra_zbin_dsigma_pz_onetime.c
#file=e_profile_calibrationw2_void_jzfield_ad_cra_zbin_dsigma_pz_onetime.c
file=e_profile_calibrationw2_void_jzfield_ad_cra_zbin_dsigma_pz_onetime_omp.c
#file=num_profile_cfhtlens_voidUSE.c
#file=e_profile_calibrationw2_map.c
#gcc mymath.c linklist.c read_clusters.c get_z_dal.c $file $mdir/Romberg.c $mdir/power.c -lm -I. -I $mdir -lfftw3 -fopenmp  -o read -g  #w1,2,3,4


#file=e_profile_cfhtlens_random_for_cluster.c
#file=e_profile_cfhtlens_find_saveallgrid_voidUSE.c
#file=e_profile_cfhtlens_find_voidUSE.c
#file=e_profile_cfhtlens_find_void_COM.c
#file=e_profile_cfhtlens_random_for_void.c
#file=e_profile_cfhtlens_find_mask.c
#file=e_profile_cfhtlens_void_fof.c
gcc mymath.c linklist.c read_clusters.c get_z_dal.c fft_m.c mask_region.c thread_assign.c $file $mdir/Romberg.c $mdir/power.c -lm -I. -I $mdir -lfftw3 -fopenmp  -o read -g

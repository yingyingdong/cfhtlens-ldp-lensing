for i in 0 1 2 3
do
    ./read ${i}
done
